package com.kuang.lesson05;

import com.kuang.lesson05.utils.JdbcUtils_DBCP;
import com.kuang.lesson05.utils.JdbcUtils_c3p0;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class TestC3P0 {
    public static void main(String[] args) {
        Connection conn = null;
        PreparedStatement st = null;
        ResultSet rs = null;
        try{
            //获取数据库连接
            conn = JdbcUtils_c3p0.getConnection();
            // 原本自己实现，现在用别人实现的
            String sql = "insert into users(id,name,password,email,birthday) values(?,?,?,?,?)";
            st = conn.prepareStatement(sql);
            st.setInt(1, 6);
            //id是int类型的
            st.setString(2, "c3p0");
            //name是varchar(字符串类型)
            st.setString(3, "123");
            //password是varchar(字符串类型)
            st.setString(4, "24736743@qq.com");
            //email是varchar(字符串类型)
            st.setDate(5, new Date(System.currentTimeMillis()));
            //birthday是date类型

            int i = st.executeUpdate();
             if (i>0){
                 System.out.println("插入成功"); }
            }catch (Exception e) {
                e.printStackTrace();
            }finally{ //释放资源
            JdbcUtils_c3p0.release(conn, st, rs);
        }
    }
}
