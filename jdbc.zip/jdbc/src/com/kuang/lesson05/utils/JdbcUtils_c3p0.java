package com.kuang.lesson05.utils;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import org.apache.commons.dbcp2.BasicDataSourceFactory;

import javax.sql.DataSource;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class JdbcUtils_c3p0 {

    private static ComboPooledDataSource ds = null;


    static {
        try {
//            // 代码版本配置   不常用
//             dataSource = new ComboPooledDataSource();
//             dataSource.setDriverClass();
//             dataSource.setUser();
//             dataSource.setPassword();
//             dataSource.setJdbcUrl();
//
//             dataSource.setMaxPoolSize();
//             dataSource.setMinPoolSize();
//

            //创建数据源 工厂模式 创建对象
            //配置文件写法
            ds = new ComboPooledDataSource();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 获取连接

    public static Connection getConnection() throws SQLException {
        return ds.getConnection();
    }


    // 释放连接资源

    public static void release(Connection conn, Statement st, ResultSet rs){
        if (rs!=null){
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if(st!=null){
            try {
                st.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if(conn!=null){
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }
}
