package com.kuang.lesson02;

import com.kuang.lesson02.utils.JdbcUtils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class SQL注入 {
    public static void main(String[] args) {

        login("'or '1=1","123456");
    }

    // 登陆
    public static void login(String username,String password){

        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        try{
            conn = JdbcUtils.getConnection();
            st = conn.createStatement();

            String sql = "select * from users where name='"+username+"' and password='"+password+"'";

            rs = st.executeQuery(sql);
            while(rs.next()){
                System.out.println(rs.getString("name"));
                System.out.println(rs.getString("password"));
                System.out.println("==============");
            }
        }catch (Exception e) {
        }finally{
            JdbcUtils.release(conn, st, rs);
    }
    }
}
